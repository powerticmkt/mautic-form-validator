=== Mautic E-mail Validation ===
Contributors: luizeof
Donate link: https://powertic.com/
Tags: mautic, email, validation
Requires at least: 4.6
Tested up to: 4.8.3
Stable tag: 1.0.5
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Valida o e-mail digitado em um campo do tipo email
