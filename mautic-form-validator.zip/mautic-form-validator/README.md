# README #

Este plugin verifica se o e-mail digitado em um campo do tipo "email" está correto
e exibe um modal caso haja alguma sugestão.

### Instalação ###

Basta instalar o plugin no Wordpress e ele funcionará automaticamente!

Faça o download da última versão do plugin em
